<?php

namespace App;
use Illuminate\Database\Eloquent\Model;


class UtlityCat extends Model
{

	protected $table = 'slj_utlity_cat';
	protected $fillable = [
		'category_name'
		
    ];
}