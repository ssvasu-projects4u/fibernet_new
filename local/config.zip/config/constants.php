<?php

return [ 
		
		/* Web */
        'base_url'             => 'http://sljfiber.ridsys.in:8080/',
		
    
  
        
];