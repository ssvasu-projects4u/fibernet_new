<!DOCTYPE html>
<html>
<head>
    <title>SLJFIBER NETWORKS</title>
</head>
<body>
<div>
    Name: {{ $name }}
</div>

    <p>Thank you</p>
</body>
</html>