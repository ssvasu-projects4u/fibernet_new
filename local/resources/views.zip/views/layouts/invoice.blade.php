<!DOCTYPE html>
<html lang="en">
<body id="page-top invoice-border">

        <!-- Begin Page Content -->
        <div class="container-fluid">

          @yield('content')

        </div>
        <!-- /.container-fluid -->
</body>

</html>
